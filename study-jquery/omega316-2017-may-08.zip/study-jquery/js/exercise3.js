$(document).ready(function(){
    $('#movies a[href]').attr('target','_blank');
});