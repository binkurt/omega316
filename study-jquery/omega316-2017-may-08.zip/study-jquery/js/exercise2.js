$(document).ready(function(){
    $('.panel-heading').css('border','solid red 3px');
});