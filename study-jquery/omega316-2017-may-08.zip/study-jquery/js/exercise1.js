$(document).ready(function(){
    $('table#movies tbody tr:even').css('border','solid red 3px');
});