var Move = function (guess, message) {
    var self = this;
    self.guess = guess;
    self.message = message;
};

var GameViewModel = function () {
    var self = this;

    self.secret = createSecret();
    self.tries = 0;
    self.history = [];

    self.isGamePlayed = function () {
        return self.tries > 0 || self.history.length > 0;
    };

    function createSecret() {
        return Math.floor(Math.random() * 100) + 1;
    };

    function initGame(message) {
        self.history.splice(0);
        self.tries = 0;
        self.history.push(new Move(self.secret, message));
        self.secret = createSecret();
        return;
    }

    self.play = function (guess) {
        var message;
        self.tries++;
        if (guess == self.secret) {
            return initGame("You win!");
        } else if (self.tries > 7) {
            return initGame("You lose!");
        } else if (guess < self.secret) {
            message = "Pick larger!";
        } else {
            message = "Pick smaller!";
        }
        self.history.push(new Move(guess, message));
    };
};

var viewModel = new GameViewModel();
var domModel = {};

var application = function () {
    domModel.btnPlay = document.getElementById("btnPlay");
    domModel.tries = document.getElementById("tries");
    domModel.divTries = document.getElementById("divTries");
    domModel.history = document.getElementById("history");
    domModel.guessInputText = document.getElementById("guess");
    new GameController(viewModel, domModel);
};

var GameController = function (viewModel, domModel) {

    var self = this;

    self.viewModel = viewModel;
    self.domModel = domModel;

    updateView();

    function createTableRow(at, move) {
        var row = self.domModel.history.insertRow(at);
        var firstCell = row.insertCell(0);
        var secondCell = row.insertCell(1);
        firstCell.innerHTML = move.guess;
        secondCell.innerHTML = move.message;
    }

    function updateView() {
        if (self.viewModel.tries==0){
            self.domModel.divTries.style.visibility = "hidden";
        } else {
            self.domModel.divTries.style.visibility = "";
        }
        self.domModel.tries.innerHTML = self.viewModel.tries.toString();
        if (self.viewModel.tries == 0) {
            self.domModel.history.innerHTML = "";
        }
        if (self.viewModel.isGamePlayed()) {
            var i = self.viewModel.history.length - 1;
            var move = self.viewModel.history[i];
            createTableRow(i, move);
        }
    };

    self.domModel.btnPlay.onclick = function () {
        var guess = Number(self.domModel.guessInputText.value);
        self.viewModel.play(guess);
        updateView();
    };
};

window.onload = application;